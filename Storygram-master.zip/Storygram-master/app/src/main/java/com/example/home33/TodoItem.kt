package com.example.home33

data class TodoItem(var id : Int, var date : String, var task : String, var completion : Boolean)


