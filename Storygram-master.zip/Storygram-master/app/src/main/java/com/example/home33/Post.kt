package com.example.home33

data class Post(
    val id: Long,
    val title: String,
    val content: String,
    val date: String,
    val tag: String,
    val imageUrl: String
)
