package com.cookandroid.diary_recyclerview

data class TodoItem(var id : Int, var date : String, var task : String, var completion : Boolean)


